# Youtube-View-Bomer
Not made by me btw, this was made by my friend fanta after we wizzed a server and wanted to get some views. Just change the YT Links &amp; Click enter in the console once you open it. Not much, pretty simple.
